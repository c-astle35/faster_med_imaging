function output = fftfiltration(input,ifilter);
%--------------------------------------------------------------------
%  This function performs linear filtration of the input
%  in the first variable (along the columns of the array)
%  in the frequency domain, i.e. using the FFT. 
%  Input parameter "ifilter" determines the use of an additional
%  smoothing filter
%    ifilter = 0  -> no additional filtration
%    ifilter = 1  -> additional cosine filter is applied 
%--------------------------------------------------------------------
%   Leonid Kunyansky, U. of Arizona, Tucson, leonk@math.arizona.edu
%
%   Written for MSRI Graduate Workshop on Inverse Problems, 2009
%====================================================================

[nlines,nproj] = size(input);

output = zeros(nlines,nproj);

M = 4;
nextended = (nlines-1)*M+1;

inpu = zeros(nextended-1,1);

for npr = 1:nproj
   inpu(1:nlines-1,1) = input(1:nlines-1,npr);
%   output(1:nlines-1,npr) = fourierfilt(inpu,nlines) ;
   outp = fourierfilt(inpu,nextended,ifilter)/M ;
   output(1:nlines-1,npr) = outp(1:nlines-1);

end % for

end
