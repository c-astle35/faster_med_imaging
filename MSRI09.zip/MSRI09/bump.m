function res = bump(rmax,rmin,r);
%--------------------------------------------------------------------
% This subroutine returns a value of an infinetely smooth function
% that equals 0 for r > rmax, equals 1 for r < rmin, and decreases
% smoothly between rmin and rmax.
% It is assumed that rmin is either lesser than rmax (smooth transition),
% or equal to rmax, in which case this is a step function.
%
%--------------------------------------------------------------------
%   Leonid Kunyansky, U. of Arizona, Tucson, leonk@math.arizona.edu
%
%   Written for MSRI Graduate Workshop on Inverse Problems, 2009
%====================================================================


if(rmax > rmin)
   x = (abs(r)-rmin)/(rmax-rmin);

   if(x >= 1.0)
      res = 0.0;
   else
      if(x > 1.0e-20)
         res = exp(2.0*exp( -1.0/x )/(x-1.0));
      else
         res = 1.d0;
      end
   end
else
   if(abs(r) >rmax)
      res = 0.0;
   else
      res = 1.0;
   end

end

end

