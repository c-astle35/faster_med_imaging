function result = filtration(input,mode);
%--------------------------------------------------------------------
%  This function performs linear filtration of the input
%  in the first variable (along the columns of the array).
%  Input parameter mode determines the type of filtration:
%    'f' = lambda filtration (differentiation combined with the Hilbert
%          transform) --- this filter is used in the FBP algorithm
%    'l' = double differetiation, used for the "local" tomography.
%    '0' = no filtration performed
%
%--------------------------------------------------------------------
%   Leonid Kunyansky, U. of Arizona, Tucson, leonk@math.arizona.edu
%
%   Written for MSRI Graduate Workshop on Inverse Problems, 2009
%====================================================================

[nlines,nproj] = size(input);

pstep = 2/(nlines-1);

%% ========================================================================
if(mode == 'f') % Standard FBP filtration

   %-------- differentiation --------------
   deriv1  = zeros([nlines,nproj]);
   deriv  = zeros([nlines,nproj]);

   for npr = 1:nproj
      for j = 2:nlines-1
         deriv1(j,npr) = (input(j+1,npr) - input(j-1,npr))/(2*pstep);
      end % for
   end % for
   
   nmed = (nlines+1)/2;
   num = 1:nlines-1;
   for npr = 1:nproj
       oneproj = input(1:nlines-1,npr);
       transform = fftshift(fft(fftshift(oneproj)));
       for j = 1:nlines-1
          transform(j) = pi*i*(j-nmed)*transform(j);
       end
%       plot(num,real(transform),num,imag(transform));
       oneproj = fftshift(ifft(fftshift(transform)));
       plot(num,real(oneproj),num,deriv1(1:nlines-1,npr));
   %    pause;
       drawnow;
       deriv(1:nlines-1,npr) = oneproj;
   end % for

   deriv = deriv1;
   
   %-------- Hilbert transform -----------

   result = zeros([nlines,nproj]);

   filtr = zeros(1,nlines);

   filtr(1) = 0;
   filtr(2) = 2/pi*log(2);

   for j = 3:nlines
       n = j-1;
       filtr(j) = 1/pi*( n*log(1 - 1/(n*n) ) + log( (n+1)/(n-1)) );
   end % for

   %----------------- convolution

   for npr = 1:nproj
      for j = 1:nlines
         for k = 1:nlines
             jmk = j-k;
             if(jmk >= 0)
                filt =  filtr(jmk+1);
             else
                filt = -filtr(-jmk+1);
             end % if
             result(j,npr) = result(j,npr) + filt*deriv(k,npr);
         end % for
      end % for
   end
   return
end % if

%% ========================================================================
if(mode == '0')   % no filtration at all
    result = -input;
    return
end % if

%% =========================================================================
if(mode == 'l')   % local tomography, filtration = second derivative

   %-------- differentiation --------------
   result  = zeros([nlines,nproj]);

   for npr = 1:nproj
      for j = 2:nlines-1
         result(j,npr) = (input(j+1,npr) - 2.0*input(j,npr)...
                         + input(j-1,npr) )/(pstep*pstep);
      end % for
   end % for

    return
end % if

end % function