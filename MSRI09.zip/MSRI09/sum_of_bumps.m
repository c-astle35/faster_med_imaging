function a = sum_of_bumps(ndim,rcx,rcy,radouter,radinner,amp);
%--------------------------------------------------------------------
% This subroutine will generate an array of the size ndim x ndim
% with values of the function consisting of several circular "bumps"
% defined by the following parameters:
%  rcx, rcy = the arrays of length nbump, corresponding to the
%       x and y coordinates of the "bumps'" centers
%       (the grid is defined within the unit square [-1,1] x [-1,1] )
%  radouter,radinner = arrays defining the outer and inner radii
%       of each of the bumps
%  amp = array with the amplitudes of each bump (can be of any sign).
%
%--------------------------------------------------------------------
%   Leonid Kunyansky, U. of Arizona, Tucson, leonk@math.arizona.edu
%
%   Written for MSRI Graduate Workshop on Inverse Problems, 2009
%====================================================================

[ndummy,nbump] = size(rcx);

a    = zeros(ndim,ndim);
step = 2.0/(ndim-1);

for iy = 1 : ndim
    y = -1.0+(iy-1) * step;
    for ix = 1: ndim
        x = -1.0 + (ix-1)*step;
        for k = 1: nbump
            dist = sqrt((x-rcx(k))*(x-rcx(k))+(y-rcy(k))*(y-rcy(k)));
            a(iy,ix) = a(iy,ix) ...
                   + amp(k)*bump(radouter(k),radinner(k),dist);
        end
    end
end


end
